// RAIM AR 자율주행 — AR(WebXR·ARCore) 버전 1단계
// ARCore가 카메라 움직임을 추적하고, 카메라 영상의 마커로 디오라마 위치를 한 번 맞춘다.
// 맞춘 뒤에는 마커가 화면에 없어도 자동차가 계속 달린다. (바리케이드·건물 가림은 다음 단계)
import * as THREE from 'three';
import { markerCorners } from './geometry.js';
import { RoadPoseTracker, toFullRes } from './tracking.js';
import { RoadMosaic, snapPathToLane } from './lane.js';
import { smoothPath, buildPath, carPoseAt, CarController } from './logic.js';
import { loadConfig, storeConfig, loadShared, downloadShared, sharedLabel } from './store.js';
import { makeCar } from './scene.js';
import { isSheetMap } from './config.js';
import {
  intrinsicsFromProjection, worldFromCv, levelEstimate, AlignmentFuser, roadToWorldMatrix, roadToCv, rayToRoad, worldToRoad,
} from './xr-align.js';
import { XRCameraReader } from './xr-camera.js';

const AR = window.AR;
const $ = (id) => document.getElementById(id);
let cfg = loadConfig();
const save = () => storeConfig(cfg);

// ---------- 설정에서 나오는 값 (마커 버전과 같은 규칙) ----------
const roadH = () => cfg.roadHeight || 0;
const markerSize = () => (cfg.roadMarkers[0] ? cfg.roadMarkers[0].size : 3);
function carDims() {
  const k = cfg.car.scale || 1;
  return { length: cfg.car.length * k, width: cfg.car.width * k, height: cfg.car.height * k, color: cfg.car.color };
}
function driveOpts() {
  const d = cfg.drive, k = d.speedScale || 1;
  return { cruise: d.cruise * k, accel: d.accel * k, decel: d.decel * k, brakeDist: d.brakeDist * k, stopGap: d.stopGap, carLength: carDims().length };
}
function liftPose(pose, h) {
  const R = pose.R, t = pose.t;
  return { R, t: [t[0] + R[2] * h, t[1] + R[5] * h, t[2] + R[8] * h] };
}
const roadIds = () => new Set(cfg.roadMarkers.map((m) => m.id));
function mapBounds() {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const m of cfg.roadMarkers) { x0 = Math.min(x0, m.x); y0 = Math.min(y0, m.y); x1 = Math.max(x1, m.x); y1 = Math.max(y1, m.y); }
  return { x0, y0, x1, y1 };
}

// ---------- 3D ----------
const renderer = new THREE.WebGLRenderer({ canvas: $('three'), alpha: true, antialias: true });
renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
renderer.setSize(window.innerWidth, window.innerHeight, false);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.02, 50);
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.6));
const sun = new THREE.DirectionalLight(0xffffff, 1.4);
sun.position.set(-0.5, 2, 0.8);
scene.add(sun);

const diorama = new THREE.Group(); // 도로 좌표(cm) → 세계(m)
diorama.matrixAutoUpdate = false;
diorama.visible = false;
scene.add(diorama);
const roadLayer = new THREE.Group(); // 도로 면 높이만큼 올린 층: 차·경로
diorama.add(roadLayer);
const markerLayer = new THREE.Group(); // 마커 지도 위치 표시 (실제 마커와 겹치면 위치가 맞은 것)
diorama.add(markerLayer);
const recordGroup = new THREE.Group();
roadLayer.add(recordGroup);
let carObj = null, pathLine = null, P = null, controller = null;
const markerVis = new Map();

function rebuildWorld(keepProgress = true) {
  const frac = controller && P ? controller.s / P.length : 0;
  P = buildPath(smoothPath(cfg.path, true, 0.5, cfg.car.length * 0.3), true);
  controller = new CarController(driveOpts());
  if (keepProgress) controller.s = frac * P.length;
  if (carObj) roadLayer.remove(carObj);
  carObj = makeCar(carDims());
  roadLayer.add(carObj);
  if (pathLine) roadLayer.remove(pathLine);
  pathLine = new THREE.Line(new THREE.BufferGeometry().setFromPoints(P.pts.map((p) => new THREE.Vector3(p[0], p[1], 0.05))),
    new THREE.LineBasicMaterial({ color: 0x38d9ff, transparent: true, opacity: 0.8 }));
  roadLayer.add(pathLine);
  roadLayer.position.z = roadH();
  // 마커 테두리
  markerLayer.clear(); markerVis.clear();
  for (const m of cfg.roadMarkers) {
    const cs = markerCorners(m).map(([x, y]) => new THREE.Vector3(x, y, 0.05));
    const mat = new THREE.LineBasicMaterial({ color: 0x3ddc84 });
    const line = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(cs), mat);
    markerLayer.add(line); markerVis.set(m.id, mat);
  }
  const key = JSON.stringify(cfg.roadMarkers) + '|' + roadH();
  if (!mosaic || mosaic.key !== key) { mosaic = RoadMosaic.forMarkers(cfg.roadMarkers); mosaic.key = key; }
}

// ---------- 상태 ----------
let session = null, refSpace = null, binding = null, reader = null, hitSource = null;
let detector = null;
const roadTracker = new RoadPoseTracker();
const fuser = new AlignmentFuser();
let mosaic = null;
let lastT = null, lastDet = -Infinity, detMs = 0, fps = 0;
let lastSeen = new Map(); // 마커 id → 마지막으로 본 시각
let showPath = true, showMarkers = true;
let trackingPoor = false;
const recording = { active: false, pts: [], snapped: null };
const heightMeasure = { active: false, until: 0, samples: [] };
let flashUntil = 0;
let lastSnap = null;

// ---------- 시작 화면 ----------
function describeMap() {
  const n = cfg.roadMarkers.length;
  const isSheet = isSheetMap(cfg.roadMarkers);
  $('mapInfo').innerHTML = `마커 지도: <b>${n}개</b> · 마커 크기 ${markerSize()}cm${isSheet ? ' (A4 테스트 시트 기본값)' : ''}<br>` +
    `경로: ${cfg.pathStale ? '<b>없음</b> · AR 안에서 [경로 기록]으로 만들어요' : `점 ${cfg.path.length}개`} · 도로 높이 ${roadH().toFixed(2)}cm` +
    (isSheet ? '<br><span style="color:var(--amber)">디오라마에서 쓰려면 먼저 마커 버전에서 [마커 지도 만들기]를 해 주세요.</span>' : '');
}
async function checkSupport() {
  describeMap();
  if (!AR) { $('startMsg').textContent = '마커 인식 라이브러리를 불러오지 못했어요.'; return; }
  if (!window.isSecureContext) { $('startMsg').textContent = 'https 주소로 열어야 AR을 쓸 수 있어요.'; return; }
  let ok = false;
  try { ok = !!navigator.xr && await navigator.xr.isSessionSupported('immersive-ar'); } catch (e) { /* 아래 */ }
  if (!ok) {
    $('startMsg').innerHTML = '이 기기·브라우저는 AR(WebXR)을 지원하지 않아요.<br>갤럭시 기기의 Chrome에서 열거나, <a href="index.html">마커 버전</a>을 쓰세요.';
    return;
  }
  $('startMsg').textContent = '';
  $('btnStart').disabled = false;
}

async function startAR() {
  $('btnStart').disabled = true;
  try {
    session = await navigator.xr.requestSession('immersive-ar', {
      requiredFeatures: ['local'],
      optionalFeatures: ['camera-access', 'hit-test', 'dom-overlay', 'anchors'],
      domOverlay: { root: $('ui') },
    });
  } catch (e) {
    $('startMsg').textContent = 'AR을 시작하지 못했어요: ' + (e.message || e);
    $('btnStart').disabled = false;
    return;
  }
  const f = session.enabledFeatures || [];
  if (f.length && !f.includes('camera-access')) {
    session.end();
    $('startMsg').textContent = '이 기기는 AR 중 카메라 영상 접근(camera-access)이 안 돼서 마커로 위치를 맞출 수 없어요.';
    return;
  }
  session.addEventListener('end', onEnd);
  session.addEventListener('select', onSelect);
  await renderer.xr.setSession(session);
  refSpace = renderer.xr.getReferenceSpace();
  // three.js는 'layers' 기능이 있을 때만 binding을 만들어서 안드로이드에서는 직접 만든다
  try { binding = renderer.xr.getBinding() || new XRWebGLBinding(session, renderer.getContext()); } catch (e) { binding = null; flash('카메라 영상 연결 실패: ' + e.message, 8000); }
  try { reader = new XRCameraReader(renderer.getContext()); } catch (e) { flash('카메라 영상 준비 실패: ' + e.message, 8000); }
  renderer.resetState();
  try {
    const viewer = await session.requestReferenceSpace('viewer');
    hitSource = await session.requestHitTestSource({ space: viewer });
  } catch (e) { hitSource = null; }
  detector = new AR.Detector({ dictionaryName: 'ARUCO_MIP_36h12' });
  fuser.reset(); roadTracker.reset();
  diorama.visible = false;
  lastT = null;
  $('start').hidden = true;
  $('ui').hidden = false;
  if (cfg.pathStale) flash('경로가 없어요 · 위치가 맞으면 [경로 기록]으로 만들어 주세요', 5000);
  renderer.setAnimationLoop(onXRFrame);
}

function onEnd() {
  renderer.setAnimationLoop(null);
  session = null; hitSource = null; binding = null; reader = null;
  setRecording(false);
  $('ui').hidden = true;
  $('start').hidden = false;
  $('btnStart').disabled = false;
  describeMap();
}

// ---------- 프레임 ----------
function onXRFrame(t, frame) {
  if (!frame || !session) return; // AR이 끝난 직후 한 번 더 불릴 수 있음
  const dt = lastT === null ? 0 : Math.min(0.1, (t - lastT) / 1000);
  lastT = t;
  if (dt > 0) fps = fps * 0.9 + 0.1 / dt;
  const pose = frame.getViewerPose(refSpace);
  if (pose) {
    trackingPoor = !!pose.emulatedPosition;
    const view = pose.views[0];
    const rate = fuser.ready && !recording.active ? 3 : 6; // 초당 인식 횟수
    if (reader && binding && view.camera && t - lastDet > 1000 / rate) {
      lastDet = t;
      detect(view, t);
    }
    if (heightMeasure.active) measureHeight(frame, t);
  }
  const A = fuser.result;
  if (fuser.ready) {
    diorama.matrix.set(...roadToWorldMatrix(A));
    diorama.matrixWorldNeedsUpdate = true;
  }
  diorama.visible = fuser.ready;
  // 차
  controller.update(dt, P, null, carDims().width / 2 + cfg.drive.margin);
  const q = carPoseAt(P, controller.s, carDims().length * 0.6);
  carObj.position.set(q.x, q.y, 0);
  carObj.rotation.set(0, 0, q.heading);
  carObj.visible = !recording.active && !cfg.pathStale;
  pathLine.visible = !cfg.pathStale && (showPath || recording.active);
  markerLayer.visible = showMarkers;
  const now = performance.now();
  for (const [id, mat] of markerVis) mat.color.set(now - (lastSeen.get(id) || -1e9) < 600 ? 0x3ddc84 : 0x1f6f45);
  renderer.render(scene, camera);
  updateHud(t);
}

function detect(view, t) {
  const t0 = performance.now();
  let img = null;
  // 카메라 영상을 읽으려면 잠시 다른 프레임버퍼에 그려야 한다. 끝나면 three.js 상태를 초기화하고
  // AR 층(렌더 타깃)을 다시 지정해야 한다 — 안 하면 이 프레임의 차가 보이지 않는 화면에 그려져 깜빡인다
  const rt = renderer.getRenderTarget();
  try { img = reader.read(binding, view); } catch (e) { img = null; }
  renderer.resetState();
  renderer.setRenderTarget(rt);
  if (!img) return;
  const raw = detector.detect(img);
  detMs = detMs * 0.8 + (performance.now() - t0) * 0.2;
  const ids = roadIds();
  const markers = raw.map((m) => ({ id: m.id, c: toFullRes(m.corners, 1) }));
  const road = markers.filter((m) => ids.has(m.id));
  reader.feedback(road.length > 0);
  const now = performance.now();
  for (const m of road) lastSeen.set(m.id, now);
  const K = intrinsicsFromProjection(view.projectionMatrix, img.width, img.height);
  const wc = worldFromCv(view.transform.matrix);
  if (road.length) {
    const r = roadTracker.update(road, cfg.roadMarkers, K, t);
    if (r.pose) {
      const vis = cfg.roadMarkers.filter((m) => road.some((q) => q.id === m.id));
      const anchor = [vis.reduce((s, m) => s + m.x, 0) / vis.length, vis.reduce((s, m) => s + m.y, 0) / vis.length, 0];
      fuser.add(levelEstimate(r.pose, wc, anchor), r.count);
    }
  }
  // 경로 기록 중: 차선 맞추기용 도로 영상 모으기
  if (recording.active && fuser.ready && mosaic) mosaic.accumulate(img, K, liftPose(roadToCv(fuser.result, wc), roadH()));
}

// ---------- 화면 탭 → 경로 점 ----------
function onSelect(e) {
  if (!recording.active || !fuser.ready) return;
  const p = e.frame.getPose(e.inputSource.targetRaySpace, refSpace);
  if (!p) return;
  const m = p.transform.matrix;
  const o = [m[12], m[13], m[14]];
  const d = [-m[8], -m[9], -m[10]];
  const L = Math.hypot(...d);
  const q = rayToRoad(fuser.result, o, d.map((v) => v / L), roadH());
  if (!q) return;
  recording.pts.push([+q[0].toFixed(2), +q[1].toFixed(2)]);
  recording.snapped = null;
  refreshRecordVis();
}
// 버튼을 누를 때는 AR 탭(select)이 생기지 않게
$('ui').addEventListener('beforexrselect', (e) => { if (e.target.closest('button')) e.preventDefault(); });

function refreshRecordVis() {
  recordGroup.clear();
  const s = cfg.car.width / 1.8;
  const geo = new THREE.SphereGeometry(0.35 * s, 12, 8);
  const mat = new THREE.MeshBasicMaterial({ color: 0xff00aa });
  for (const p of recording.pts) {
    const b = new THREE.Mesh(geo, mat);
    b.position.set(p[0], p[1], 0.35 * s);
    recordGroup.add(b);
  }
  if (recording.pts.length > 1) {
    recordGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([...recording.pts, recording.pts[0]].map((p) => new THREE.Vector3(p[0], p[1], 0.1))),
      new THREE.LineBasicMaterial({ color: 0xff00aa, transparent: true, opacity: recording.snapped ? 0.35 : 1 })));
  }
  if (recording.snapped) {
    const sp = smoothPath(recording.snapped, true, 0.5);
    recordGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([...sp, sp[0]].map((p) => new THREE.Vector3(p[0], p[1], 0.15))),
      new THREE.LineBasicMaterial({ color: 0x3ddc84 })));
  }
}
function setRecording(on) {
  recording.active = on;
  recording.pts = [];
  recording.snapped = null;
  refreshRecordVis();
  $('recordBar').hidden = !on;
  $('mainButtons').hidden = on;
}
function snapRecording() {
  if (recording.pts.length < 4) { flash('점을 4개 이상 찍은 뒤 눌러 주세요'); return; }
  const res = snapPathToLane(mosaic, recording.pts, {
    search: cfg.lane.search || markerSize() * 1.2, step: Math.max(mosaic.cell * 2, markerSize() / 10), laneWidth: cfg.lane.width || null,
  });
  lastSnap = res;
  if (!res.ok) {
    flash(res.reason === 'coverage' ? '경로 주변 도로를 덜 비췄어요 · 탭한 곳을 따라 천천히 한 번 더 비춘 뒤 다시 눌러 주세요'
      : '흰 선을 찾지 못했어요 · 더 가까이서 비추거나, 탭을 더 촘촘히 해 주세요', 4000);
    return;
  }
  recording.snapped = res.pts;
  refreshRecordVis();
  flash(`차선에 맞췄어요 · 흰 선을 찾은 구간 ${(res.validFrac * 100).toFixed(0)}% · 차선 폭 약 ${res.laneWidth.toFixed(1)}cm`, 4000);
}

// ---------- 도로 높이 자동 측정: ARCore가 찾은 바닥(도로 면)의 높이 ----------
function measureHeight(frame, t) {
  if (t > heightMeasure.until) {
    heightMeasure.active = false;
    const s = heightMeasure.samples.sort((a, b) => a - b);
    if (s.length < 10) { flash('도로 면을 찾지 못했어요 · 도로를 비스듬히 비추며 다시 눌러 주세요', 4000); return; }
    const med = s[s.length >> 1];
    setRoadHeight(med, `도로 높이 ${med >= 0 ? '+' : ''}${med.toFixed(2)}cm (자동 · ${s.length}점)`);
    return;
  }
  if (!hitSource || !fuser.ready) return;
  const hits = frame.getHitTestResults(hitSource);
  if (!hits.length) return;
  const p = hits[0].getPose(refSpace);
  if (!p) return;
  const w = p.transform.position;
  const r = worldToRoad(fuser.result, [w.x, w.y, w.z]);
  const b = mapBounds(), pad = markerSize();
  if (r[0] > b.x0 + pad && r[0] < b.x1 - pad && r[1] > b.y0 + pad && r[1] < b.y1 - pad && Math.abs(r[2]) < 20) heightMeasure.samples.push(r[2]);
}
function setRoadHeight(h, msg) {
  cfg.roadHeight = +Math.max(-10, Math.min(20, h)).toFixed(3);
  save();
  rebuildWorld(true);
  flash(msg || `도로 높이 ${cfg.roadHeight >= 0 ? '+' : ''}${cfg.roadHeight.toFixed(2)}cm · 차가 도로에 붙어 보이면 맞아요`, 2500);
}

// ---------- 화면 글 ----------
let hudT = 0;
function flash(msg, ms = 3000) {
  $('status').textContent = msg;
  $('status').className = 'ok';
  flashUntil = performance.now() + ms;
}
function updateHud(t) {
  if (t - hudT < 150) return;
  hudT = t;
  const now = performance.now();
  const seen = [...lastSeen.entries()].filter(([, s]) => now - s < 600).length;
  $('debug').textContent = `${fps.toFixed(0)}fps · 인식 ${detMs.toFixed(0)}ms · 마커 ${seen}개 · 맞춤 ${fuser.count}${reader && reader.flipLocked ? '' : ' · 영상 방향 확인 중'}`;
  const st = controller.state === 'drive' ? '주행' : controller.state === 'brake' ? '감속' : '정지';
  $('drive').firstChild.textContent = `${st} · ${controller.v.toFixed(1)}cm/s · 차 ×${(cfg.car.scale || 1).toFixed(2)}`;
  $('speedBar').style.width = `${Math.min(100, (controller.v / controller.o.cruise) * 100)}%`;
  if (now < flashUntil) return;
  let msg, ok = false;
  if (heightMeasure.active) msg = `도로 면을 찾는 중… 도로 위를 비스듬히 비춰 주세요 (${heightMeasure.samples.length}점)`;
  else if (trackingPoor) msg = '카메라 추적이 불안정해요 · 천천히 움직이며 바닥을 비춰 주세요';
  else if (!fuser.ready) msg = `디오라마 테두리의 도로 마커를 비춰 주세요 · 위치 맞추는 중 ${fuser.count}/${fuser.minCount}`;
  else if (recording.active) { msg = recording.snapped ? '차선에 맞춘 경로(초록) · 괜찮으면 [완료·저장]' : `점 ${recording.pts.length}개 · 차선 가운데를 탭 (곡선은 2~3번)`; ok = true; }
  else if (cfg.pathStale) msg = '경로가 없어요 · [경로 기록]으로 만들어 주세요';
  else { msg = seen ? '위치 맞춤 완료 · 마커를 볼 때마다 더 정확해져요' : '위치 맞춤 완료 · 마커가 안 보여도 계속 달려요'; ok = true; }
  $('status').textContent = msg;
  $('status').className = ok ? 'ok' : 'warn';
}

// ---------- 버튼 ----------
$('btnStart').onclick = startAR;
$('btnExit').onclick = () => { if (session) session.end(); };
$('btnRealign').onclick = () => { fuser.reset(); roadTracker.reset(); flash('위치를 다시 맞춰요 · 도로 마커를 비춰 주세요'); };
$('btnRecord').onclick = () => { if (!fuser.ready) { flash('먼저 마커로 위치를 맞춰 주세요'); return; } setRecording(true); };
$('recUndo').onclick = () => { if (recording.snapped) recording.snapped = null; else recording.pts.pop(); refreshRecordVis(); };
$('recCancel').onclick = () => setRecording(false);
$('recSnap').onclick = snapRecording;
$('recDone').onclick = () => {
  if (recording.pts.length < 4) { flash('점을 4개 이상 찍어 주세요'); return; }
  cfg.path = (recording.snapped || recording.pts).slice();
  cfg.pathStale = false;
  save();
  setRecording(false);
  rebuildWorld(false);
};
$('btnPath').onclick = () => { showPath = !showPath; $('btnPath').classList.toggle('off', !showPath); };
$('btnMarkers').onclick = () => { showMarkers = !showMarkers; $('btnMarkers').classList.toggle('off', !showMarkers); };
function setCarScale(k) { cfg.car.scale = +Math.max(0.5, Math.min(5, k)).toFixed(2); save(); rebuildWorld(true); flash(`자동차 크기 ×${cfg.car.scale.toFixed(2)}`, 1500); }
$('carBigger').onclick = () => setCarScale((cfg.car.scale || 1) * 1.25);
$('carSmaller').onclick = () => setCarScale((cfg.car.scale || 1) / 1.25);
function setSpeedScale(k) {
  cfg.drive.speedScale = +Math.max(0.25, Math.min(5, k)).toFixed(2); save();
  controller.o = driveOpts();
  flash(`자동차 속도 ×${cfg.drive.speedScale.toFixed(2)} · ${controller.o.cruise.toFixed(1)}cm/s`, 1500);
}
$('speedUp').onclick = () => setSpeedScale((cfg.drive.speedScale || 1) * 1.25);
$('speedDown').onclick = () => setSpeedScale((cfg.drive.speedScale || 1) / 1.25);
$('heightUp').onclick = () => setRoadHeight(roadH() + markerSize() / 40);
$('heightDown').onclick = () => setRoadHeight(roadH() - markerSize() / 40);
$('btnHeightAuto').onclick = () => {
  if (!fuser.ready) { flash('먼저 마커로 위치를 맞춰 주세요'); return; }
  if (!hitSource) { flash('이 기기는 바닥 인식(hit-test)이 안 돼요 · 높이 −/+로 맞춰 주세요', 4000); return; }
  heightMeasure.active = true; heightMeasure.samples = []; heightMeasure.until = lastT + 3000;
};
function setMenuCollapsed(c) {
  $('mainButtons').classList.toggle('collapsed', c);
  $('btnMenu').textContent = c ? '메뉴 펴기' : '메뉴 접기';
  $('btnMenu').setAttribute('aria-expanded', String(!c));
  try { localStorage.setItem('raim-ar-xr-menu-collapsed', c ? '1' : '0'); } catch (e) { /* 무시 */ }
}
$('btnMenu').onclick = () => setMenuCollapsed(!$('mainButtons').classList.contains('collapsed'));
try { if (localStorage.getItem('raim-ar-xr-menu-collapsed') === '1') setMenuCollapsed(true); } catch (e) { /* 무시 */ }
window.addEventListener('resize', () => { if (!session) renderer.setSize(window.innerWidth, window.innerHeight, false); });

rebuildWorld(false);
checkSupport();
// 사이트에 전시 설정(diorama.json)이 있고 새것이면 불러온다
async function applySharedConfig(force) {
  const r = await loadShared(cfg, { force });
  if (r.status === 'applied') {
    cfg = r.cfg;
    fuser.reset(); roadTracker.reset();
    rebuildWorld(false);
    describeMap();
    $('sharedMsg').textContent = `전시 설정(${sharedLabel(r.shared)} 저장)을 불러왔어요`;
  } else if (force) {
    $('sharedMsg').textContent = r.status === 'bad' ? '사이트의 diorama.json 내용이 올바르지 않아요.' : '사이트에 올라간 전시 설정(diorama.json)이 아직 없어요.';
  }
}
applySharedConfig(false);
$('btnExport').onclick = () => { downloadShared(cfg); $('sharedMsg').textContent = 'diorama.json을 받았어요. 이 파일을 사이트에 올리면 모든 기기가 같은 지도·경로를 써요.'; };
$('btnShared').onclick = () => applySharedConfig(true);

// 시험용
window.__raimAR = {
  get state() {
    return { roadMarkers: cfg.roadMarkers, path: cfg.path, ready: fuser.ready, count: fuser.count, align: fuser.result, s: controller.s, v: controller.v, recPts: recording.pts, snapped: recording.snapped, lastSnap, roadHeight: roadH() };
  },
};
