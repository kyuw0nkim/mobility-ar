// 설정 저장 (마커 버전·AR 버전이 같은 브라우저 저장소를 함께 씀)
import { DEFAULT_CONFIG } from './config.js';

export const STORE_KEY = 'raim-ar-marker-config-v1';
export function clone(o) { return JSON.parse(JSON.stringify(o)); }
export function mergeDeep(base, over) {
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over || {})) out[k] = k in base ? mergeDeep(base[k], over[k]) : over[k];
  return out;
}
export function loadConfig() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) return mergeDeep(clone(DEFAULT_CONFIG), JSON.parse(raw));
  } catch (e) { /* 저장소 사용 불가 */ }
  return clone(DEFAULT_CONFIG);
}
export function storeConfig(cfg) {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(cfg)); } catch (e) { /* 무시 */ }
}
