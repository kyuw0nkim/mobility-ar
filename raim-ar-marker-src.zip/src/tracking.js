// 프레임 단위 계산 (화면·DOM 없음): 도로 자세, 바리케이드 위치
import {
  homography, poseFromHomography, refinePose, invertPose, composePose,
  transformPoint, mulVec3, markerCorners,
} from './geometry.js';

// markers: [{id, c:[[u,v]x4]}] (원본 해상도 좌표)
export function solveRoadPose(markers, roadMarkers, K) {
  const byId = new Map(roadMarkers.map((m) => [m.id, m]));
  const obj = [], ip = [];
  let count = 0;
  for (const m of markers) {
    const def = byId.get(m.id);
    if (!def) continue;
    count++;
    const cs = markerCorners(def);
    for (let k = 0; k < 4; k++) { obj.push(cs[k]); ip.push(m.c[k]); }
  }
  if (obj.length < 4) return { count, pose: null, H: null, nPts: obj.length };
  const H = homography(obj.map((p) => [p[0], p[1]]), ip);
  if (!H) return { count, pose: null, H: null, nPts: obj.length };
  const pose = refinePose(K, poseFromHomography(H, K), obj, ip, 5);
  const ok = pose.rms < 8 && pose.t[2] > 0;
  return { count, pose: ok ? pose : null, H, nPts: obj.length, rms: pose.rms };
}

// camPose: 도로 → 카메라. 반환: 도로 좌표의 바리케이드 {x, y, dx, dy, z} 또는 null
export function solveBarricade(markers, bc, K, camPose) {
  const local = markerCorners({ x: 0, y: 0, size: bc.markerSize, rot: 0 });
  const tableFromCam = invertPose(camPose);
  const found = [];
  for (const m of markers) {
    if (!bc.markerIds.includes(m.id)) continue;
    const Hm = homography(local.map((p) => [p[0], p[1]]), m.c);
    if (!Hm) continue;
    const pm = refinePose(K, poseFromHomography(Hm, K), local, m.c, 5);
    if (pm.rms > 6) continue;
    const tm = composePose(tableFromCam, pm);
    const c = transformPoint(tm, [0, 0, 0]);
    const d = mulVec3(tm.R, [1, 0, 0]);
    const L = Math.hypot(d[0], d[1]);
    if (L < 0.3) continue; // 마커가 눕혀져 있으면 방향 판단 불가
    found.push({ x: c[0], y: c[1], z: c[2], dx: d[0] / L, dy: d[1] / L });
  }
  if (!found.length) return null;
  let obs = found[0];
  if (found.length > 1) {
    const f2 = found[1];
    const sgn = f2.dx * obs.dx + f2.dy * obs.dy < 0 ? -1 : 1;
    obs = { x: (obs.x + f2.x) / 2, y: (obs.y + f2.y) / 2, z: (obs.z + f2.z) / 2, dx: obs.dx + sgn * f2.dx, dy: obs.dy + sgn * f2.dy };
    const L = Math.hypot(obs.dx, obs.dy) || 1;
    obs.dx /= L; obs.dy /= L;
  }
  return obs;
}
