// AR 세션의 카메라 영상(camera-access)을 작은 크기로 줄여 CPU로 읽어 온다 (마커 인식·차선 영상용).
// getCameraImage()가 주는 텍스처는 그 프레임 안에서만 쓸 수 있어서, 프레임 콜백 안에서 바로 그려 읽는다.
// three.js와 같은 WebGL 문맥을 쓰므로 끝나면 renderer.resetState()를 불러 줘야 한다.

const VS = `#version 300 es
in vec2 p;
out vec2 uv;
void main() { uv = p * 0.5 + 0.5; gl_Position = vec4(p, 0.0, 1.0); }`;
const FS = `#version 300 es
precision mediump float;
uniform sampler2D cam;
uniform float flipY;
in vec2 uv;
out vec4 color;
void main() {
  vec2 t = vec2(uv.x, flipY > 0.5 ? 1.0 - uv.y : uv.y);
  color = texture(cam, t);
}`;

export class XRCameraReader {
  // maxPixels: 줄인 영상의 픽셀 수 한도 (가로·세로 어느 방향으로 들어도 인식 시간이 비슷하도록)
  constructor(gl, maxPixels = 300000) {
    this.gl = gl;
    this.maxPixels = maxPixels;
    this.w = 0; this.h = 0;
    this.flip = false; // 영상 위아래 방향: 마커가 잡히는 쪽으로 자동 결정
    this.flipLocked = false;
    const sh = (type, src) => {
      const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    this.prog = prog;
    this.uFlip = gl.getUniformLocation(prog, 'flipY');
    this.uCam = gl.getUniformLocation(prog, 'cam');
    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);
    this.buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'p');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    this.fbo = gl.createFramebuffer();
    this.tex = gl.createTexture();
  }

  ensureSize(camW, camH) {
    const k = Math.min(1, Math.sqrt(this.maxPixels / (camW * camH)));
    const w = Math.round(camW * k), h = Math.round(camH * k);
    if (w === this.w && h === this.h) return;
    const gl = this.gl;
    this.w = w; this.h = h;
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.tex, 0);
    this.pixels = new Uint8ClampedArray(w * h * 4);
  }

  // binding: XRWebGLBinding, view: XRView (view.camera 필요). 반환: {width, height, data}(위쪽이 0행) 또는 null
  read(binding, view) {
    const cam = view.camera;
    if (!cam) return null;
    const camTex = binding.getCameraImage(cam);
    if (!camTex) return null;
    const gl = this.gl;
    this.ensureSize(cam.width, cam.height);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.viewport(0, 0, this.w, this.h);
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.BLEND); gl.disable(gl.CULL_FACE); gl.disable(gl.SCISSOR_TEST);
    gl.colorMask(true, true, true, true);
    gl.useProgram(this.prog);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, camTex);
    gl.uniform1i(this.uCam, 0);
    // readPixels는 아래쪽 행부터 주므로, 영상 위쪽이 프레임버퍼 아래(0행)에 오도록 그린다
    gl.uniform1f(this.uFlip, this.flip ? 1 : 0);
    gl.bindVertexArray(this.vao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.bindVertexArray(null);
    gl.readPixels(0, 0, this.w, this.h, gl.RGBA, gl.UNSIGNED_BYTE, this.pixels);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return { width: this.w, height: this.h, data: this.pixels };
  }

  // 마커 인식 결과로 위아래 방향 정하기: 한쪽에서 계속 안 잡히면 뒤집어 보고, 잡히면 고정
  feedback(found) {
    if (this.flipLocked) return;
    if (found) { this.miss = 0; this.hits = (this.hits || 0) + 1; if (this.hits >= 3) this.flipLocked = true; return; }
    this.hits = 0;
    this.miss = (this.miss || 0) + 1;
    if (this.miss >= 4) { this.flip = !this.flip; this.miss = 0; }
  }
}
