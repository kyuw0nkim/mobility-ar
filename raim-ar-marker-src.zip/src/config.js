// 기본 설정 = A4 가로 테스트 시트 (단위: cm, 원점: 시트 왼쪽 아래, x 오른쪽, y 위쪽)
// 실제 디오라마에서는 설정 화면에서 마커 위치와 크기를 실측값으로 바꾼다.
import { roundedRectPath } from './logic.js';

export const SHEET = { width: 29.7, height: 21.0 };

export const ROAD = { x0: 7.5, y0: 6.0, x1: 22.2, y1: 15.0, r: 3.5, laneWidth: 3.4 };

export const DEFAULT_CONFIG = {
  version: 1,
  // 도로(디오라마) 기준 마커: id, 중심 x·y, 검은 사각형 한 변 size, 마커 위쪽 방향 rot(도)
  roadMarkers: [
    { id: 0, x: 2.4, y: 2.4, size: 3.0, rot: 0 },
    { id: 1, x: 14.85, y: 2.4, size: 3.0, rot: 0 },
    { id: 2, x: 27.3, y: 2.4, size: 3.0, rot: 0 },
    { id: 3, x: 27.3, y: 18.6, size: 3.0, rot: 0 },
    { id: 4, x: 14.85, y: 18.6, size: 3.0, rot: 0 },
    { id: 5, x: 2.4, y: 18.6, size: 3.0, rot: 0 },
  ],
  barricade: {
    markerIds: [10, 11], // 앞면·뒷면
    markerSize: 3.0,
    width: 10.0, // 바닥에서 도로를 막는 폭
    height: 5.0, // 화면 표시용 높이
  },
  car: { length: 3.6, width: 1.8, height: 1.3, color: '#e2453c' },
  drive: {
    cruise: 3.0, // cm/s
    brakeDist: 6.0, // 이 거리 안에서 감속 시작 (cm)
    stopGap: 1.2, // 바리케이드 앞 정지 여유 (cm)
    accel: 2.5,
    decel: 1.5,
    margin: 0.6, // 차 폭 절반에 더하는 여유 (cm)
  },
  tracking: {
    procWidth: 640, // 인식용 축소 영상 폭 (px)
    smoothing: 0.45, // 카메라 자세 보정 (0~1, 클수록 빠르게 따라감)
    lostMs: 700,
    focalAuto: true,
    focalFactor: 0.8, // 기본 초점거리 = 영상 긴 변 × 값
  },
  barricadeTracking: { confirmFrames: 3, windowFrames: 6, clearMs: 2000, smoothing: 0.35 },
  path: roundedRectPath(ROAD.x0, ROAD.y0, ROAD.x1, ROAD.y1, ROAD.r, 8),
  pathIsRaw: false, // true면 기록한 점을 그대로 부드럽게 처리
};
