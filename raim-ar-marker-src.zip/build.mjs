// 단일 HTML 파일로 빌드 (외부 네트워크 없이 동작): dist/index.html(마커 버전), dist/ar.html(AR 버전)
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const esc = (s) => s.replace(/<\/script/gi, '<\\/script');
const cv = esc(readFileSync('node_modules/js-aruco2/src/cv.js', 'utf8'));
const aruco = esc(readFileSync('node_modules/js-aruco2/src/aruco.js', 'utf8'));
mkdirSync('dist', { recursive: true });

for (const [entry, page, out] of [['src/app.js', 'src/index.html', 'dist/index.html'], ['src/ar-app.js', 'src/ar.html', 'dist/ar.html']]) {
  const res = await build({
    entryPoints: [entry],
    bundle: true,
    minify: true,
    format: 'iife',
    target: ['chrome100'],
    write: false,
    legalComments: 'none',
  });
  const appJs = esc(res.outputFiles[0].text);
  let html = readFileSync(page, 'utf8');
  html = html.replace('<!--ARUCO-->', () => `<script>\n${cv}\n</script>\n<script>\n${aruco}\n</script>`);
  html = html.replace('<!--APP-->', () => `<script>\n${appJs}\n</script>`);
  writeFileSync(out, html);
  console.log(out, (html.length / 1024).toFixed(0) + ' KB');
}
