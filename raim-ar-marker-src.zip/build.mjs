// 단일 HTML 파일로 빌드 (외부 네트워크 없이 동작)
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const res = await build({
  entryPoints: ['src/app.js'],
  bundle: true,
  minify: true,
  format: 'iife',
  target: ['chrome100'],
  write: false,
  legalComments: 'none',
});
const esc = (s) => s.replace(/<\/script/gi, '<\\/script');
const appJs = esc(res.outputFiles[0].text);
const cv = esc(readFileSync('node_modules/js-aruco2/src/cv.js', 'utf8'));
const aruco = esc(readFileSync('node_modules/js-aruco2/src/aruco.js', 'utf8'));

let html = readFileSync('src/index.html', 'utf8');
html = html.replace('<!--ARUCO-->', () => `<script>\n${cv}\n</script>\n<script>\n${aruco}\n</script>`);
html = html.replace('<!--APP-->', () => `<script>\n${appJs}\n</script>`);
mkdirSync('dist', { recursive: true });
writeFileSync('dist/index.html', html);
console.log('dist/index.html', (html.length / 1024).toFixed(0) + ' KB');
